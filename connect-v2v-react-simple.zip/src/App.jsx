import React, { useEffect, useState } from 'react'
import 'amazon-connect-streams'

export default function App() {
  const [status, setStatus] = useState('Waiting for call...')
  const [contactId, setContactId] = useState(null)

  useEffect(() => {
    window.connect.core.initCCP(document.getElementById('ccp'), {
      ccpUrl: 'https://YOUR_CONNECT_INSTANCE.awsapps.com/connect/ccp-v2',
      loginPopup: true,
      loginPopupAutoClose: true,
      softphone: { allowFramedSoftphone: true }
    })

    window.connect.contact((contact) => {
      setContactId(contact.getContactId())

      contact.onRinging(() => setStatus('Incoming call ringing'))
      contact.onConnected(() => setStatus('Call connected'))
      contact.onEnded(() => setStatus('Call ended'))
    })
  }, [])

  return (
    <div style={{ padding: 16 }}>
      <h2>Amazon Connect V2V – Simple React App</h2>
      <p>Status: <strong>{status}</strong></p>
      {contactId && <p>Contact ID: {contactId}</p>}
      <div id="ccp" style={{ width: 400, height: 600, border: '1px solid #ccc' }} />
    </div>
  )
}
